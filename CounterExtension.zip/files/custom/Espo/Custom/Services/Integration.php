<?php

namespace Espo\Custom\Services;

use Espo\Core\Templates\Services\Base;

class Integration extends Base
{
    protected function init()
    {
        $this->addManager('IntegrationManager');
    }
}

