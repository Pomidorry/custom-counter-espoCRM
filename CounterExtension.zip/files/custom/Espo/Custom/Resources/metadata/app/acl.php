<?php

return [
    'admin' => [
        'scopeList' => [
            'Integration' => [
                'allow' => true,
            ],
        ],
    ],
];
