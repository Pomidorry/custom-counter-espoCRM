<?php

namespace Espo\Modules\CustomCounter\Jobs;

use Espo\Services\Record;
use Espo\ORM\EntityManager;
use Espo\Entities\Integration;
use LogicException;
use Espo\ApiClient\Client;
use Espo\Core\Utils\Log;
use Espo\ApiClient\Exception\ResponseError;

class EspoApiClient
{
    private $url;
    private $userName = null;
    private $password = null;
    protected $urlPath = '/api/v1/';
    private $lastCh;
    private $lastResponse;
    private $apiKey = null;
    private $secretKey = null;

    public function __construct($url = null, $userName = null, $password = null)
    {
        if (isset($url)) {
            $this->url = $url;
        }
        if (isset($userName)) {
            $this->userName = $userName;
        }
        if (isset($password)) {
            $this->password = $password;
        }
    }

    public function setUrl($url)
    {
        $this->url = $url;
    }

    public function setUserName($userName)
    {
        $this->userName = $userName;
    }

    public function setPassword($password)
    {
        $this->password = $password;
    }

    public function setApiKey($apiKey)
    {
        $this->apiKey = $apiKey;
    }

    public function setSecretKey($secretKey)
    {
        $this->secretKey = $secretKey;
    }

    public function request($method, $action, array $data = null)
    {
        try {
            $method = strtoupper($method);

            $this->checkParams();

            $this->lastResponse = null;
            $this->lastCh = null;

            $url = $this->normalizeUrl($action);

            $ch = curl_init($url);

            if ($ch === false) {
                throw new \Exception('Failed to initialize cURL session.');
            }

            $headerList = [];

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            if ($this->apiKey && $this->secretKey) {
                $string = $method . ' /' . $action;
                $authPart = base64_encode($this->apiKey . ':' . hash_hmac('sha256', $string, $this->secretKey, true));
                $authHeader = 'X-Hmac-Authorization: ' .  $authPart;
                $headerList[] = $authHeader;
                
            } else if ($this->apiKey) {
                $authHeader = 'X-Api-Key: ' .  $this->apiKey;
                $headerList[] = $authHeader;
            }

            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_HEADER, true);

            if ($method != 'GET') {
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            }

            if (isset($data)) {
                if ($method == 'GET') {
                    curl_setopt($ch, CURLOPT_URL, $url. '?' . http_build_query($data));
                } else {
                    $payload = json_encode($data);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
                    $headerList[] = 'Content-Type: application/json';
                    $headerList[] = 'Content-Length: ' . strlen($payload);
                }
            }

            if (!empty($headerList)) {
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headerList);
            }

            $this->lastResponse = curl_exec($ch);

            if (curl_errno($ch)) {
                throw new \Exception('cURL error: ' . curl_error($ch));
            }

            $this->lastCh = $ch;

            // Log the raw response for better error diagnostics
	$parsedResponse = $this->parseResponse($this->lastResponse);
	$responseCode = $this->getResponseHttpCode();

	$header = $this->normalizeHeader($parsedResponse['header']);
	$errorMessage = !empty($header['X-Status-Reason']) ? $header['X-Status-Reason'] : 'EspoClient: Unknown Error';

	echo "Response Code: " . $responseCode . "\n";
	echo "Response Headers: " . print_r($header, true) . "\n";
	echo "Response Body: " . print_r($parsedResponse['body'], true) . "\n";

	curl_close($ch);
	throw new \Exception($errorMessage, $responseCode);

        } catch (\Exception $e) {
            throw new \Exception('Request failed: ' . $e->getMessage());
        }
    }

    public function getResponseContentType()
    {
        return $this->getInfo(CURLINFO_CONTENT_TYPE);
    }

    public function getResponseTotalTime()
    {
        return $this->getInfo(CURLINFO_TOTAL_TIME);
    }

    public function getResponseHttpCode()
    {
        return $this->getInfo(CURLINFO_HTTP_CODE);
    }

    protected function normalizeUrl($action)
    {
    	echo $this->url . $this->urlPath . $action;
        return $this->url . $this->urlPath . $action;
    }

    protected function checkParams()
    {
        $paramList = ['url'];

        foreach ($paramList as $name) {
            if (empty($this->$name)) {
                throw new \Exception('EspoClient: Parameter "'.$name.'" is not defined.');
            }
        }

        return true;
    }

    protected function getInfo($option)
    {
        if (isset($this->lastCh)) {
            return curl_getinfo($this->lastCh, $option);
        }
        throw new \Exception('No active cURL session.');
    }

    protected function parseResponse($response)
    {
        $headerSize = $this->getInfo(CURLINFO_HEADER_SIZE);

        if ($headerSize === false) {
            throw new \Exception('Unable to parse response.');
        }

        return [
            'header' => trim(substr($response, 0, $headerSize)),
            'body' => substr($response, $headerSize),
        ];
    }

    protected function normalizeHeader($header)
    {
        preg_match_all('/(.*): (.*)\r\n/', $header, $matches);

        $headerArray = [];
        foreach ($matches[1] as $index => $name) {
            if (isset($matches[2][$index])) {
                $headerArray[$name] = trim($matches[2][$index]);
            }
        }

        return $headerArray;
    }
}

class CounterJob extends Record
{
    protected $entityManager;

    public function __construct(EntityManager $entityManager, Log $log)
    {
        $this->entityManager = $entityManager;
        $this->log = $log;
    }
    public function run()
    {
        $counterEntity = $this->entityManager->getEntity('Counter');
        
	$currentDate = date('Y-m-d H:i:s');  
	$numberOfRecords = $this->countRecords();
	$dbSize = $this->calculateDatabaseSize();
	$numberOfUsers = $this->countUsers();
	$diskSize = $this->calculateDiskSize();
	
	$counterEntity->set('numberOfUsers', $numberOfUsers);
        $counterEntity->set('name', $currentDate);
	$counterEntity->set('numberOfRecords', $numberOfRecords);
	$counterEntity->set('size', $dbSize);
	$counterEntity->set('diskSize', $diskSize);
	
        $this->entityManager->saveEntity($counterEntity);
        
	$data = [
	    'name' => $currentDate . ' post',	
	    'numberOfRecords' => $numberOfRecords,
	    'numberOfUsers' => $numberOfUsers,
	    'diskSize' => $diskSize,
	    'size' => $dbSize
	];
	$this->sendDataViaApi($data);
        return true; 
    }
    
    protected function sendDataViaApi($data)
    {   
	$apiKey = $this->entityManager->getEntityById(Integration::ENTITY_TYPE, 'Counter')?->get('apiKey') ?? null;
	$secretKey = $this->entityManager->getEntityById(Integration::ENTITY_TYPE, 'Counter')?->get('secretKey') ?? null;
	$destinationUrl = $this->entityManager->getEntityById(Integration::ENTITY_TYPE, 'Counter')?->get('destinationUrl') ?? null;
	
	if (!$apiKey || !$secretKey || !$destinationUrl) {
             $this->log->debug('API credentials are not set.');
            return false;
        }
        

	try {
           $client = new EspoApiClient($destinationUrl);
           $client->setApiKey($apiKey);
           $client->setSecretKey($secretKey);

           //$response = $client->request('GET', 'Counter');
           $response = $client->request('POST', 'Counter', $data);
   
	} catch (\Exception $e) {
	    echo 'Error: ' . $e->getMessage();
	}
    }
    
    function countRecords()
    {
        $pdo = $this->getEntityManager()->getPDO();
        $stmt = $pdo->query("SELECT SUM(TABLE_ROWS) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE()");
        return (int) $stmt->fetchColumn();
    }
    
    protected function countUsers()
    {
        $pdo = $this->getEntityManager()->getPDO();
        $stmt = $pdo->query("SELECT COUNT(*) FROM user");
        return (int) $stmt->fetchColumn();
    }

    protected function calculateDatabaseSize()
    {
        $pdo = $this->getEntityManager()->getPDO();
        $stmt = $pdo->query("SELECT SUM(data_length + index_length) FROM information_schema.tables WHERE table_schema = DATABASE()");
        $size = $stmt->fetchColumn();
        return round($size / (1024 * 1024 * 1024), 2); 
    }	
    
    protected function calculateDiskSize()
    {
        $path = realpath(__DIR__ . '/espocrm'); 
        $io = popen('/usr/bin/du -sk ' . $path, 'r');
	$size = fgets($io, 4096);
        pclose($io);
        $size = explode("\t", $size);
        return round($size[0] / (1024 * 1024), 2); 
    }


}

