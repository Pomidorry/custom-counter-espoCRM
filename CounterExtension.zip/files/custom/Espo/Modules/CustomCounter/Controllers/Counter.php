<?php

namespace Espo\Modules\CustomCounter\Controllers;

class Counter extends \Espo\Core\Templates\Controllers\Base
{
}
