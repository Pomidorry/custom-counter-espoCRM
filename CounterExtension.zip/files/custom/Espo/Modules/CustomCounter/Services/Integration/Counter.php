<?php

namespace Espo\Modules\CustomCounter\Services\Integration;

use Espo\Core\Templates\Services\Base;

class Counter extends Base
{
    protected function init()
    {
        $this->addManager('IntegrationManager');
    }
}

