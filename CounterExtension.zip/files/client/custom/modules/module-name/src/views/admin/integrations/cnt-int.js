define(['views/admin/integrations/edit'], Dep => {
	return class extends Dep {};
});
